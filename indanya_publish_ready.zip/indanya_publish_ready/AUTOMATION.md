# 淫談屋：自動記事の受け入れ仕様

## 構造

- `index.html`：ホーム。`data/articles.json`を読み、新着順に自動表示する。
- `articles/<slug>.html`：公開記事。
- `data/articles.json`：記事一覧とホーム表示用メタデータ。
- `tools/add_article.py`：生成した記事HTMLとJSONをサイトへ追加する。

## 自動記事ツールの出力

1. 完成した記事HTMLを1個作る。
2. 記事メタデータJSONを1個作る。
3. `python tools/add_article.py metadata.json article.html`を実行する。
4. GitHubへcommit/pushする。GitHub Pagesが自動で公開する。

## 必須メタデータ

- `id`：記事の一意ID
- `slug`：URL用英数字
- `title`：タイトル
- `category`：カテゴリ
- `status`：`published`でホームへ表示
- `published_at`：ISO 8601
- `display_date`：画面表示日
- `comments`：表示するコメント数
- `thumbnail`：サムネイルURL
- `source_url`：元情報
- `images_used`：使用画像数

## 画像記事の原則

使える画像は全部使う。除外するのは重複、低画質、無関係、使用不可、個人情報等の危険画像のみ。

## 公開受け入れ口

静的サイトなので、公開サイトへ直接POSTする方式ではなく、GitHubリポジトリを受け入れ口にする。
自動記事ツールはGitHub Contents APIまたはgit pushで、記事HTMLと`data/articles.json`を更新する。
