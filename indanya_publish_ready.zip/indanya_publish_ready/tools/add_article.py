#!/usr/bin/env python3
"""Add one generated article to the static 淫談屋 site.

Usage:
  python tools/add_article.py article.json article.html

article.json must contain:
  id, slug, title, category, published_at, display_date,
  thumbnail, source_url, images_used
"""
from __future__ import annotations
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "articles.json"
ARTICLES = ROOT / "articles"


def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: python tools/add_article.py article.json article.html", file=sys.stderr)
        return 2

    metadata_path = Path(sys.argv[1])
    html_path = Path(sys.argv[2])
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))

    required = {
        "id", "slug", "title", "category", "published_at",
        "display_date", "thumbnail", "source_url", "images_used"
    }
    missing = sorted(required - metadata.keys())
    if missing:
        raise ValueError(f"Missing fields: {', '.join(missing)}")

    slug = metadata["slug"]
    if not slug.replace("-", "").replace("_", "").isalnum():
        raise ValueError("slug must contain only letters, numbers, '-' and '_'")

    destination = ARTICLES / f"{slug}.html"
    ARTICLES.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(html_path, destination)

    metadata = {
        **metadata,
        "status": metadata.get("status", "published"),
        "comments": int(metadata.get("comments", 0)),
        "url": f"articles/{slug}.html",
    }

    articles = json.loads(DATA.read_text(encoding="utf-8")) if DATA.exists() else []
    articles = [item for item in articles if item.get("id") != metadata["id"] and item.get("slug") != slug]
    articles.append(metadata)
    articles.sort(key=lambda item: item["published_at"], reverse=True)
    DATA.write_text(json.dumps(articles, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Added: {destination.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
